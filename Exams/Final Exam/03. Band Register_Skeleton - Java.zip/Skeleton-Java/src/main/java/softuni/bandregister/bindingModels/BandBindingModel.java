package softuni.bandregister.bindingModels;

public class BandBindingModel {
    //TODO
}
